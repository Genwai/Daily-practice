$('.show-fw').hover(function  () {
	$(".fwly-open").show();
},function  () {
	$('.fwly-open').hide()
})
